
import { Component, OnInit } from '@angular/core';
import {gql, Apollo} from 'apollo-angular';
import { Hotel } from '../models/hotels';

const Get_MyHotels = gql`
 query{
  MyHotels{
    hotel_id,
    hotel_name,
    street,
    city,
    postal_code,
    price,
    email,
    user_id
  }
}
`;



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  allHotels:Hotel[] = [];
  constructor(private apollo: Apollo){}
  ngOnInit(): void {
    this.apollo.watchQuery<any>({
     query: Get_MyHotels
    })
    .valueChanges
    .subscribe(({data, loading}) => {
     console.log(loading);
      this.allHotels = data.MyHotels;
    })
  }
}


/*
import { Component, OnInit } from '@angular/core';
import {gql, Apollo} from 'apollo-angular';
import { Hotel } from '../models/hotels';

const Get_BrandFilter = gql`
query ($brand:String){
  BrandFilter(brand:$brand){
    Id,
    ProductName,
    Brand
  }
}`;

// Some code hidden for display purpose

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  allGadets:Hotel[] = [];
  selectedBrand:string = '';


  searchByBrand(){
   this.apollo.watchQuery<any>({
      query: Get_BrandFilter,
      variables:{
        brand: this.selectedBrand
      }
    })
    .valueChanges
    .subscribe(({data, loading}) => {
      console.log(loading);
      this.allHotels = data.BrandFilter;
    });
  }
}
*/



