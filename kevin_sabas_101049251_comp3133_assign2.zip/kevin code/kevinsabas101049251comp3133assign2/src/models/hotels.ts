export interface Hotel {
  hotel_id: number;
  hotel_name: string,
  street: string,
  city: string,
  postal_code: string,
  price: number,
  email: string,
  user_id: number
 }
